package egireon.modid;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_2168;
import net.minecraft.class_2561;

import static net.minecraft.class_2170.*;

public class PhantomCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(method_9247("phantoms")
            .then(method_9247("spawn")
                .then(method_9247("true")
                    .executes(context -> {
                        var player = context.getSource().method_44023();
                        if (player == null) {
                            context.getSource().method_9213(class_2561.method_43471("command.phantoms.error.not_player"));
                            return 0;
                        }
                        PhantomConfig.setSpawnEnabled(player, true);
                        context.getSource().method_9226(() -> class_2561.method_43471("command.phantoms.spawn.enabled"), false);
                        return 1;
                    })
                )
                .then(method_9247("false")
                    .executes(context -> {
                        var player = context.getSource().method_44023();
                        if (player == null) {
                            context.getSource().method_9213(class_2561.method_43471("command.phantoms.error.not_player"));
                            return 0;
                        }
                        PhantomConfig.setSpawnEnabled(player, false);
                        context.getSource().method_9226(() -> class_2561.method_43471("command.phantoms.spawn.disabled"), false);
                        return 1;
                    })
                )
            )
        );
    }
}