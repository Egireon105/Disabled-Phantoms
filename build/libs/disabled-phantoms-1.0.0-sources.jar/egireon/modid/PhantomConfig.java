package egireon.modid;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_3222;

public class PhantomConfig {
    // Храним настройки в оперативной памяти (сбрасываются при перезапуске сервера)
    private static final Map<UUID, Boolean> settings = new HashMap<>();

    public static boolean isSpawnEnabled(class_3222 player) {
        // По умолчанию true (фантомы спавнятся)
        return settings.getOrDefault(player.method_5667(), true);
    }

    public static void setSpawnEnabled(class_3222 player, boolean enabled) {
        settings.put(player.method_5667(), enabled);
    }
}