package egireon.modid.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import egireon.modid.PhantomConfig;

import java.util.List;
import net.minecraft.class_2910;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

@Mixin(class_2910.class)
public class PhantomSpawnerMixin {

    @Inject(method = "spawn", at = @At("HEAD"), cancellable = true)
    private void checkPlayersBeforeSpawning(class_3218 world, boolean spawnMonsters, CallbackInfo ci) {
        if (!spawnMonsters) return;
        List<class_3222> players = world.method_18456();
        if (players.isEmpty()) {
            ci.cancel();
            return;
        }
        boolean anyEnabled = players.stream().anyMatch(PhantomConfig::isSpawnEnabled);
        if (!anyEnabled) {
            ci.cancel();
        }
    }
}